import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
    public class PostgreSQLJDBC {
    public static void main(String[] args) {
        Connection connection = null;
        try {
            // Cargar el controlador JDBC
            Class.forName("org.postgresql.Driver");

            // Establecer la conexión
            String url = "jdbc:postgresql://localhost:5432/Productos";
            String user = "postgres";
            String password = "corina2102";
            connection = DriverManager.getConnection(url, user, password);

            // Verificar la conexión
            if (connection != null) {
                System.out.println("Conexión exitosa a la base de datos!");
            } else {
                System.out.println("Fallo al conectar a la base de datos.");
            }

            // Crear y ejecutar una consulta
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM tu_tabla");
            while (rs.next()) {
                System.out.println("Columna1: " + rs.getString("columna1"));
                // Más columnas...
            }
            rs.close();
            stmt.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el controlador JDBC: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        } finally {
            // Cerrar la conexión
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
