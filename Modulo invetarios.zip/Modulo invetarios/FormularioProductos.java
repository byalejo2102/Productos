import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;

public class FormularioProductos {
    private JTextField codigoField;
    private JTextField saldoInicialField;
    private JTextField ingresosField;
    private JTextField egresosField;
    private JTextField ajustesField;
    private JTextField saldoFinalField;
    private JTextField costoField;
    private JTextField precioField;
    private JTextField descripcionField;
    private JComboBox<String> unidadMedidaComboBox;
    private JComboBox<String> statusComboBox;
    private JLabel imagenLabel;
    private File imagenFile;
    private Integer currentProductoId = null;

    private final Dimension textFieldSize = new Dimension(200, 30);
    private final Font textFieldFont = new Font("Arial", Font.PLAIN, 14);

    public FormularioProductos() {
        JFrame frame = new JFrame("Datos del Producto - Editar datos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 700);
        frame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(240, 248, 255));
        frame.add(mainPanel);

        GroupLayout layout = new GroupLayout(mainPanel);
        mainPanel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        JLabel titleLabel = new JLabel("Datos del producto", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setOpaque(true);
        titleLabel.setBackground(new Color(70, 130, 180));

        JButton verProductosButton = new JButton("Ver Productos");
        verProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verProductos();
            }
        });

        // Campos de texto y etiquetas
        JLabel codigoLabel = new JLabel("Código del producto:");
        codigoField = new JTextField();
        codigoField.setPreferredSize(textFieldSize);
        codigoField.setFont(textFieldFont);

        JLabel saldoInicialLabel = new JLabel("Saldo inicial:");
        saldoInicialField = new JTextField();
        saldoInicialField.setPreferredSize(textFieldSize);
        saldoInicialField.setFont(textFieldFont);

        JLabel ingresosLabel = new JLabel("Ingresos:");
        ingresosField = new JTextField();
        ingresosField.setPreferredSize(textFieldSize);
        ingresosField.setFont(textFieldFont);

        JLabel egresosLabel = new JLabel("Egresos:");
        egresosField = new JTextField();
        egresosField.setPreferredSize(textFieldSize);
        egresosField.setFont(textFieldFont);

        JLabel ajustesLabel = new JLabel("Ajustes:");
        ajustesField = new JTextField();
        ajustesField.setPreferredSize(textFieldSize);
        ajustesField.setFont(textFieldFont);

        JLabel saldoFinalLabel = new JLabel("Saldo final:");
        saldoFinalField = new JTextField();
        saldoFinalField.setPreferredSize(textFieldSize);
        saldoFinalField.setFont(textFieldFont);

        JLabel costoLabel = new JLabel("Costo:");
        costoField = new JTextField();
        costoField.setPreferredSize(textFieldSize);
        costoField.setFont(textFieldFont);

        JLabel precioLabel = new JLabel("Precio:");
        precioField = new JTextField();
        precioField.setPreferredSize(textFieldSize);
        precioField.setFont(textFieldFont);

        JLabel descripcionLabel = new JLabel("Descripción:");
        descripcionField = new JTextField();
        descripcionField.setPreferredSize(textFieldSize);
        descripcionField.setFont(textFieldFont);

        JLabel unidadMedidaLabel = new JLabel("Unidad de medida:");
        unidadMedidaComboBox = new JComboBox<>(new String[]{"kg", "gr", "lt", "ml", "un", "m", "cm", "mm"});
        unidadMedidaComboBox.setPreferredSize(textFieldSize);
        unidadMedidaComboBox.setFont(textFieldFont);

        JLabel statusLabel = new JLabel("Status:");
        statusComboBox = new JComboBox<>(new String[]{"ACT", "INA", "DIS", "ESC"});
        statusComboBox.setPreferredSize(textFieldSize);
        statusComboBox.setFont(textFieldFont);

        JButton cargarImagenButton = new JButton("Cargar Imagen");
        cargarImagenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarImagen();
            }
        });

        imagenLabel = new JLabel();

        JButton guardarButton = new JButton("Guardar");
        guardarButton.setBackground(new Color(34, 139, 34));
        guardarButton.setForeground(Color.WHITE);
        guardarButton.setFont(new Font("Arial", Font.BOLD, 14));
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarDatos(null);
            }
        });

        JButton editarButton = new JButton("Editar");
        editarButton.setBackground(new Color(255, 140, 0));
        editarButton.setForeground(Color.WHITE);
        editarButton.setFont(new Font("Arial", Font.BOLD, 14));
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentProductoId != null) {
                    guardarDatos(currentProductoId);
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor, busque un producto para editar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        JButton cancelarButton = new JButton("Cancelar");
        cancelarButton.setBackground(new Color(178, 34, 34));
        cancelarButton.setForeground(Color.WHITE);
        cancelarButton.setFont(new Font("Arial", Font.BOLD, 14));
        cancelarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Layout horizontal
        layout.setHorizontalGroup(layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(titleLabel)
                .addComponent(codigoLabel)
                .addComponent(saldoInicialLabel)
                .addComponent(ingresosLabel)
                .addComponent(egresosLabel)
                .addComponent(ajustesLabel)
                .addComponent(saldoFinalLabel)
                .addComponent(costoLabel)
                .addComponent(precioLabel)
                .addComponent(descripcionLabel)
                .addComponent(unidadMedidaLabel)
                .addComponent(statusLabel)
                .addComponent(cargarImagenButton)
                .addComponent(imagenLabel)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(guardarButton)
                    .addComponent(editarButton)
                    .addComponent(cancelarButton)
                    .addComponent(verProductosButton))
            )
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(codigoField)
                .addComponent(saldoInicialField)
                .addComponent(ingresosField)
                .addComponent(egresosField)
                .addComponent(ajustesField)
                .addComponent(saldoFinalField)
                .addComponent(costoField)
                .addComponent(precioField)
                .addComponent(descripcionField)
                .addComponent(unidadMedidaComboBox)
                .addComponent(statusComboBox)
            )
        );

        // Layout vertical
        layout.setVerticalGroup(layout.createSequentialGroup()
            .addComponent(titleLabel)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(codigoLabel)
                .addComponent(codigoField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(saldoInicialLabel)
                .addComponent(saldoInicialField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(ingresosLabel)
                .addComponent(ingresosField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(egresosLabel)
                .addComponent(egresosField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(ajustesLabel)
                .addComponent(ajustesField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(saldoFinalLabel)
                .addComponent(saldoFinalField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(costoLabel)
                .addComponent(costoField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(precioLabel)
                .addComponent(precioField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(descripcionLabel)
                .addComponent(descripcionField))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(unidadMedidaLabel)
                .addComponent(unidadMedidaComboBox))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(statusLabel)
                .addComponent(statusComboBox))
            .addComponent(cargarImagenButton)
            .addComponent(imagenLabel)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(guardarButton)
                .addComponent(editarButton)
                .addComponent(cancelarButton)
                .addComponent(verProductosButton))
        );

        frame.setVisible(true);
    }

    private void cargarImagen() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            imagenFile = fileChooser.getSelectedFile();
            imagenLabel.setText(imagenFile.getName());

            ImageIcon icon = new ImageIcon(imagenFile.getAbsolutePath());
            Image image = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            imagenLabel.setIcon(new ImageIcon(image));
        }
    }

    private void buscarProducto() {
        String codigo = codigoField.getText();
        if (codigo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un código de producto.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Productos", "postgres", "corina2102")) {
            String sql = "SELECT * FROM PRODUCTOS WHERE PROCODIGO = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, codigo);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                currentProductoId = resultSet.getInt("PROCODIGO");
                descripcionField.setText(resultSet.getString("PRODESCRIPCION"));
                unidadMedidaComboBox.setSelectedItem(resultSet.getString("PROUNIDADMEDIDA"));
                saldoInicialField.setText(resultSet.getString("PROSALDOINICIAL"));
                ingresosField.setText(resultSet.getString("PROINGRESOS"));
                egresosField.setText(resultSet.getString("PROEGRESOS"));
                ajustesField.setText(resultSet.getString("PROAJUSTES"));
                saldoFinalField.setText(resultSet.getString("PROSALDOFINAL"));
                costoField.setText(resultSet.getString("PROCOSTOUM"));
                precioField.setText(resultSet.getString("PROPRECIOUM"));
                statusComboBox.setSelectedItem(resultSet.getString("PROSTATUS"));

                byte[] imagenBytes = resultSet.getBytes("PROFOTO");
                if (imagenBytes != null) {
                    Image img = Toolkit.getDefaultToolkit().createImage(imagenBytes);
                    img = img.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    imagenLabel.setIcon(new ImageIcon(img));
                } else {
                    imagenLabel.setIcon(null);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Producto no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al buscar el producto: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarDatos(Integer procodigo) {
        String codigo = codigoField.getText();
        String descripcion = descripcionField.getText();
        String unidadMedida = (String) unidadMedidaComboBox.getSelectedItem();
        String saldoInicial = saldoInicialField.getText();
        String ingresos = ingresosField.getText();
        String egresos = egresosField.getText();
        String ajustes = ajustesField.getText();
        String saldoFinal = saldoFinalField.getText();
        String costo = costoField.getText();
        String precio = precioField.getText();
        String status = (String) statusComboBox.getSelectedItem();

        if (codigo.isEmpty() || descripcion.isEmpty() || unidadMedida == null || saldoInicial.isEmpty() ||
                ingresos.isEmpty() || egresos.isEmpty() || ajustes.isEmpty() || saldoFinal.isEmpty() ||
                costo.isEmpty() || precio.isEmpty() || status == null) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos requeridos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Productos", "postgres", "corina2102")) {
            String sql;
            PreparedStatement statement;

            if (procodigo == null) {
                sql = "INSERT INTO PRODUCTOS (PROCODIGO, PRODESCRIPCION, PROUNIDADMEDIDA, PROSALDOINICIAL, PROINGRESOS, PROEGRESOS, PROAJUSTES, PROSALDOFINAL, PROCOSTOUM, PROPRECIOUM, PROSTATUS, PROFOTO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                statement = conn.prepareStatement(sql);
            } else {
                sql = "UPDATE PRODUCTOS SET PRODESCRIPCION = ?, PROUNIDADMEDIDA = ?, PROSALDOINICIAL = ?, PROINGRESOS = ?, PROEGRESOS = ?, PROAJUSTES = ?, PROSALDOFINAL = ?, PROCOSTOUM = ?, PROPRECIOUM = ?, PROSTATUS = ?, PROFOTO = ? WHERE PROCODIGO = ?";
                statement = conn.prepareStatement(sql);
                statement.setString(12, codigo);
            }

            statement.setString(1, codigo);
            statement.setString(2, descripcion);
            statement.setString(3, unidadMedida);
            statement.setBigDecimal(4, new BigDecimal(saldoInicial));
            statement.setBigDecimal(5, new BigDecimal(ingresos));
            statement.setBigDecimal(6, new BigDecimal(egresos));
            statement.setBigDecimal(7, new BigDecimal(ajustes));
            statement.setBigDecimal(8, new BigDecimal(saldoFinal));
            statement.setBigDecimal(9, new BigDecimal(costo));
            statement.setBigDecimal(10, new BigDecimal(precio));
            statement.setString(11, status);

            if (imagenFile != null) {
                FileInputStream fis = new FileInputStream(imagenFile);
                statement.setBinaryStream(12, fis, (int) imagenFile.length());
            } else {
                statement.setNull(12, Types.BLOB);
            }

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Datos guardados exitosamente.");
            }
        } catch (SQLException | IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al guardar los datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verProductos() {
        JFrame frame = new JFrame("Lista de Productos");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 600);

        JLabel titleLabel = new JLabel("LISTA DE PRODUCTOS", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setOpaque(true);
        titleLabel.setBackground(new Color(70, 130, 180));
        titleLabel.setForeground(Color.WHITE);
        frame.add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"Código", "Descripción", "Unidad Medida", "Saldo Inicial", "Ingresos", "Egresos", "Ajustes", "Saldo Final", "Costo", "Precio", "Status", "Foto"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 11) {
                    return ImageIcon.class;
                }
                return Object.class;
            }
        };

        cargarTodosLosProductos(model);

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    private void cargarTodosLosProductos(DefaultTableModel model) {
        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Productos", "postgres", "corina2102")) {
            String sql = "SELECT * FROM PRODUCTOS";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                String codigo = resultSet.getString("PROCODIGO");
                String descripcion = resultSet.getString("PRODESCRIPCION");
                String unidadMedida = resultSet.getString("PROUNIDADMEDIDA");
                BigDecimal saldoInicial = resultSet.getBigDecimal("PROSALDOINICIAL");
                BigDecimal ingresos = resultSet.getBigDecimal("PROINGRESOS");
                BigDecimal egresos = resultSet.getBigDecimal("PROEGRESOS");
                BigDecimal ajustes = resultSet.getBigDecimal("PROAJUSTES");
                BigDecimal saldoFinal = resultSet.getBigDecimal("PROSALDOFINAL");
                BigDecimal costo = resultSet.getBigDecimal("PROCOSTOUM");
                BigDecimal precio = resultSet.getBigDecimal("PROPRECIOUM");
                String status = resultSet.getString("PROSTATUS");

                byte[] imagenBytes = resultSet.getBytes("PROFOTO");
                ImageIcon imagenIcon = null;
                if (imagenBytes != null) {
                    Image img = Toolkit.getDefaultToolkit().createImage(imagenBytes);
                    img = img.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    imagenIcon = new ImageIcon(img);
                }

                Object[] row = {codigo, descripcion, unidadMedida, saldoInicial, ingresos, egresos, ajustes, saldoFinal, costo, precio, status, imagenIcon};
                model.addRow(row);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                mostrarLogin();
            }
        });
    }

    public static void mostrarLogin() {
        JFrame loginFrame = new JFrame("Login");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(300, 200);
        loginFrame.setLocationRelativeTo(null);

        JPanel loginPanel = new JPanel();
        loginFrame.add(loginPanel);
        placeLoginComponents(loginPanel, loginFrame);

        loginFrame.setVisible(true);
    }

    private static void placeLoginComponents(JPanel panel, JFrame loginFrame) {
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel userLabel = new JLabel("Usuario:");
        JTextField userText = new JTextField(20);
        panel.add(userLabel);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Contraseña:");
        JPasswordField passwordText = new JPasswordField(20);
        panel.add(passwordLabel);
        panel.add(passwordText);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = userText.getText();
                String password = new String(passwordText.getPassword());

                if (autenticar(user, password)) {
                    loginFrame.dispose();
                    new FormularioProductos();
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(loginButton);
    }

    private static boolean autenticar(String user, String password) {
        // Aquí puedes implementar la lógica de autenticación, por ahora se valida con datos fijos
        return "admin".equals(user) && "admin".equals(password);
    }
}
